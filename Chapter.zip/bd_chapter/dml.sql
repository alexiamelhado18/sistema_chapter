INSERT INTO Livros (Titulo, QuantidadePaginas, Disponivel) VALUES ('Titulo A', 120, 1);

INSERT INTO Livros (Titulo, QuantidadePaginas, Disponivel) VALUES ('Titulo B', 220, 0);