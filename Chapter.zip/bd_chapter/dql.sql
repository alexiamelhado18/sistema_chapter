USE Chapter;

UPDATE Livros SET Titulo = 'Titulo A1' Where Id = 1;

SELECT Id, Titulo, QuantidadePaginas, Disponivel FROM Livros;

SELECT * FROM Livros;

