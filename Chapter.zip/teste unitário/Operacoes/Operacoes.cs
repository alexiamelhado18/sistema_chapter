﻿namespace Operacoes;

public class Operacoes
{
    public static double Somar(double numero1, double numero2)
    {
        return (numero1 + numero2);
    }
}
